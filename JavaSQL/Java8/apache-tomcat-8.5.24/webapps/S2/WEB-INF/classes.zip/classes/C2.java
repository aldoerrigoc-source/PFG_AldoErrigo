public class C2 {
    public static String printChecks (String vect){
        String out="";
        out += "<html>";
        out += "<body>";
		out+="<form action=http://www.nicolasserrano.com/CS/HTML/query.html method=Get>";
		out +="<input=text name=rows value="+vect.length()+">";
		out +="<input type=submit value=Enviar>";
		for (int i=1; i<vect.length(); i++){
        }
     out +="</form>";
		
        out += "</body>";
        out += "</html>";
        return out;
    }
}